# Debug Code
RestClient.log = STDOUT # Comment this line to nil the log
DISABLE_ENCRIPTION = false
